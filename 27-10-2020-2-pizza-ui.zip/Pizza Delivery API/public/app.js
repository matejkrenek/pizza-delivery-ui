/*
* Frontend Logic for the Application
*
*/
var app = {}

app.config = {
    'sessionToken': false,
    'shoppingCart': false,
};

app.client = {}

app.client.request = function(headers, path, method, queryStringObject, payload, callback){

    headers = typeof(headers) == 'object' && headers !== 'null' ? headers : {};
    path = typeof(path) == 'string' ? path : '/';
    method = typeof(method) == 'string' && ['POST', 'GET', 'PUT', 'DELETE'].indexOf(method) > -1 ? method : 'GET';
    queryStringObject = typeof(queryStringObject) == 'object' && queryStringObject !== 'null' ? queryStringObject : {};
    payload = typeof(payload) == 'object' && payload !== 'null' ? payload : {};
    callback = typeof(callback) == 'function' ? callback : false;

    var requestUrl = path+'?';
    var counter = 0
    for(var keyQuery in queryStringObject){
        if(queryStringObject.hasOwnProperty(keyQuery)){
            counter++
            if(counter > 1){
                requestUrl+='&'
            }
            requestUrl+=keyQuery+'='+queryStringObject[keyQuery];
        }
    }

    var xhr = new XMLHttpRequest();
    xhr.open(method, requestUrl, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    for(var keyHeader in headers){
        if(headers.hasOwnProperty(keyHeader)){
            xhr.setRequestHeader(keyHeader, headers[keyHeader]);
        }
    }

    if(app.config.sessionToken){
        xhr.setRequestHeader('token_id', app.config.sessionToken.token_id);
    }

    xhr.onreadystatechange = function(){
        if(xhr.readyState == XMLHttpRequest.DONE){
            var statusCode = xhr.status;
            var responseReturned = xhr.responseText;

            if(callback){
                try{
                    var parsedResponse = JSON.parse(responseReturned)
                    callback(statusCode, parsedResponse)
                } catch(e){
                    callback(statusCode, false)
                }
            }
        }
    };


    var payloadString = JSON.stringify(payload);
    xhr.send(payloadString)

}

// Bind the logout button
app.bindLogoutButton = function(){
    document.getElementById('logoutButton').addEventListener('click', function(e){
        e.preventDefault()

        app.logCustomerOut()
    });
    
};

// Log the customer out then redirect them
app.logCustomerOut = function(){
    // Get the current token in
    var token_id = typeof(app.config.sessionToken.token_id) == 'string' ? app.config.sessionToken.token_id : false;

    // Send the current token to the tokens endpoint to delete it
    var queryStringObject = {
        'token_id': token_id,
    }
    

    app.client.request(undefined, 'api/tokens', 'DELETE', queryStringObject, undefined, function(statusCode, responsePayload){
        // set the app.config token as false
        app.setSessionToken(false);
        
        // Send the customer to the logged out page
        window.location = '/session/deleted';



    })

};

// Bind the forms
app.bindForms = function(){   
    if(document.querySelector("form")){

        var allForms = document.querySelectorAll("form");
        for(var i = 0; i < allForms.length; i++){
            allForms[i].addEventListener("submit", function(e){

            // Stop it from submiting
            e.preventDefault();
            var formId = this.id
            var path = this.action
            var method = this.method.toUpperCase();

            // Hide the error message (if it's currently shown due to a previous error)
            document.querySelector('#'+formId+' .formError').style.display = 'none'

            // Hide the success message (if it's currently shown due to a previous error)
            if(document.querySelector("#"+formId+" .formSuccess")){
                document.querySelector("#"+formId+" .formSuccess").style.display = 'none';
            }

            // Turn the inputs into a payload
            var payload = {}
            var elements = this.elements;
            for(var i = 0; i < elements.length; i++){
                if(elements[i].type !== 'submit'){
                    var valueOfElement = elements[i].type == 'checkbox' ? elements[i].checked : elements[i].value;
                    if(elements[i].name == '_method'){
                        method = valueOfElement;
                    } else{
                        payload[elements[i].name] = valueOfElement
                    }
                }
            }

            // Call the API
            app.client.request(undefined, path, method, undefined, payload, function(statusCode, responsePayload){
                if(statusCode !== 200){

                    if(statusCode == 403){
                        console.log(responsePayload)
                    } else{
                        var error = typeof(responsePayload.Error) == 'string' ? responsePayload.Error : 'An erroir has occured, please try again';


                        document.querySelector('#'+formId+' .formError').innerHTML = error
                        document.querySelector('#'+formId+' .formError').style.display = 'flex'
                        
                    }
                    
                } else{
                    app.formResponseProcessor(formId, payload, responsePayload)
                }
            });
        });
        };
    };
};

// Form response processor
app.formResponseProcessor = function(formId, requestPayload, responsePayload){
    var functionToCall = false;

    if(formId == 'customerCreate'){

        // Take the email, and use it to log the user in
        var newPayload = {
            'email_address': requestPayload.email_address,
            'password': requestPayload.password
        };

        app.client.request(undefined, 'api/tokens', 'POST', undefined, newPayload, function(newStatusCode, newResponsePayload){
            // Display an error on the form if needed
            if(newStatusCode !== 200){

                document.querySelector('#'+formId+' .formError').innerHTML = 'Sorry, an error occured. Please try again'
                document.querySelector('#'+formId+' .formError').style.display = 'flex'
            } else{
                // if successful, se the token and redirect the user
                console.log(newResponsePayload)
                app.setSessionToken(newResponsePayload);
                window.location = '/menu/pizza'
            }
        });
    }

    // If login was successful, set the token in localstorage and redirest the user
    if(formId == 'sessionCreate'){
        app.setSessionToken(responsePayload);
        window.location = '/menu/pizza'
    }

    // If forms saved successfully and they have success messages, show them
    var formsWithSuccessMessages = ['customerEdit'];
    if(formsWithSuccessMessages.indexOf(formId) > -1){
        document.querySelector('#'+formId+" .formSuccess").style.display = 'flex'

    }
};

// Get the session token from localstrorage and set it in the app.config object
app.getSessionToken = function(){
    var tokenString = localStorage.getItem('token');
    if(typeof(tokenString) == 'string'){
        try{
            var token = JSON.parse(tokenString);
            app.config.sessionToken = token;
            if(typeof(token) == 'object'){
                app.setLoggedInClass(true);
                app.shoppingCartItems(token.email_address)
            } else{
                app.setLoggedInClass(false);
            }

        } catch(e){
            app.config.sessionToken = false;
            app.setLoggedInClass(false)
        }
    }
}

app.shoppingCartItems = function(email_address){

    var queryStringObject = {
        'email_address': email_address
    }

    app.client.request(undefined, 'api/customers', 'GET', queryStringObject, undefined, function(statusCode, responsePayload){
        if(statusCode == 200){
            var shoppingCartLength = responsePayload.shopping_cart.length;
            document.querySelector('.navbar .right .shopping-cart').innerHTML = `<i class="fas fa-shopping-basket"></i><span>${shoppingCartLength}</span>`
        } else{
            
        }

        
    })    
}

app.setLoggedInClass = function(add){
    var target = document.querySelector("body");
    if(add){
        target.classList.add('loggedIn');
    } else{
        target.classList.remove('loggedIn')
    }

    if(document.body.classList.contains('loggedIn')){
        document.querySelector('.right a.account').href = '/customer/edit'
    } 
};

// Set the session token in the app.config object as well as localstorage
app.setSessionToken = function(token){
    app.config.sessionToken = token;
    var tokenString = JSON.stringify(token);
    localStorage.setItem('token', tokenString);
    if(typeof(token) == 'object'){
        app.setLoggedInClass(true)
    } else{
        app.setLoggedInClass(false)
    }
}


// Renew the token
app.renewToken = function(callback){
    var currentToken = typeof(app.config.sessionToken) == 'object' ? app.config.sessionToken : false;
    if(currentToken){
        // Update the token with new expiration
        var payload = {
            'token_id': currentToken.token_id,
            'extend': true
        };

        app.client.request(undefined, 'api/tokens', 'PUT', undefined, payload, function(statusCode, responsePayload){
            if(statusCode == 200){

                // Get the new token details
                var queryStringObject = {'token_id': currentToken.token_id};
                app.client.request(undefined, 'api/tokens', 'GET', queryStringObject, undefined, function(statusCode, responsePayload){
                    if(statusCode == 200){
                        app.setSessionToken(responsePayload);
                        callback(false)
                    }
                    else{
                        app.setSessionToken(false)
                        callback(true)
                    }
                })
            } else{
                app.setSessionToken(false);
                callback(true);
            }
        })
    } else {
        app.setSessionToken(false);
        callback(true);
    }
};

// Load data on the page
app.loadDataOnPage = function(){
    var bodyClasses = document.querySelector("body").classList;
    var primaryClass = typeof(bodyClasses[0]) == 'string' ? bodyClasses[0] : false;

    if(primaryClass == 'customerEdit'){
        app.loadCustomerEditPage();
    }
};

app.loadCustomerEditPage = function(){
    var email_address = typeof(app.config.sessionToken.email_address) == 'string' ? app.config.sessionToken.email_address : false;

    if(email_address){

        var queryStringObject = {
            'email_address':email_address
        }

        app.client.request(undefined, 'api/customers', 'GET', queryStringObject, undefined, function(statusCode, responsePayload){
            if(statusCode == 200){
                document.querySelector('#customerEdit .firstNameInput').value = responsePayload.first_name;
                document.querySelector('#customerEdit .lastNameInput').value = responsePayload.last_name;
                document.querySelector('#customerEdit .streetAddressInput').value = responsePayload.street_address;
                document.querySelector('#customerEdit .zipCodeInput').value = responsePayload.zip_code;
                document.querySelector('#customerEdit .displayEmailInput').value = responsePayload.email_address;

                document.querySelector("#customerEdit .hiddenEmailInput").value = responsePayload.email_address;

            } else{
                app.logCustomerOut()
            }
        })
    } else{
        app.logCustomerOut()
    }
}



// Loop to renew token ofter
app.tokenRenewalLoop = function(){
    setInterval(function(){
        app.renewToken(function(err){
            if(!err){
                console.log("Token renewed successfully @ "+Date.now())
            }
        });
    }, 1000*60);
};

app.bindAddToCart = function(){
    var addButton = document.querySelectorAll('.add-to-cart')

    addButton.forEach(function(btn){
        btn.addEventListener('click', function(e){
            e.preventDefault()

            app.addToTheCart(btn)
        })
    })

};

app.addToTheCart = function(btn){
    var email_address = typeof(app.config.sessionToken.email_address) == 'string' ? app.config.sessionToken.email_address : false;

    if(email_address){
        var payload = {
            'email_address': email_address,
            'addOrDelete': 'add',
            'item': btn.id
        };

        app.client.request(undefined, 'api/shopping-cart', 'PUT', undefined, payload, function(statusCode, responsePayload){
            if(statusCode == 200){
                app.shoppingCartItems(email_address)
            } else{
                console.log('ups')
            }
        })
    } else{ 
        app.logCustomerOut()
    }

}


// Init
app.init = function(){

    // Bind all form submissions
    app.bindForms();
    
    // Bind logout button
    app.bindLogoutButton()

    // Get the token from localstorage
    app.getSessionToken()

    // Renew token
    app.tokenRenewalLoop()

    // Load data on page
    app.loadDataOnPage()

    // bind add to cart button
    app.bindAddToCart()
    
};

window.onload = function(){
    app.init();
}