/*
* Frontend Logic for the Application
*
*/

var app = {}

console.log('hello worlds console')